package com.FactoryPattern;

public interface Calculate {
	public void calculate(float num1, float num2);
}
