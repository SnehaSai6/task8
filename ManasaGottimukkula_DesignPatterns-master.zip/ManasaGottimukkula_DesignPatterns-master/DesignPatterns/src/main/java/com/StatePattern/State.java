package com.StatePattern;
public interface State {

	public void perform();
}