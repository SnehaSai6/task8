package com.StatePattern;
public class TVOffState implements State {

	public void perform() {
		System.out.println("TV is turned OFF");
	}

}