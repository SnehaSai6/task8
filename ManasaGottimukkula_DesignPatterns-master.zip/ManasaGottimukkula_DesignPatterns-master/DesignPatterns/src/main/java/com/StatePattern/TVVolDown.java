package com.StatePattern;
public class TVVolDown implements State {
	
	public void perform() {
		System.out.println("TV Volume is Decreased");
	}

}